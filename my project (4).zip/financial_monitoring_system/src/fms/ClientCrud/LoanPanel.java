package fms.ClientCrud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class LoanPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<String> cbAccountHolder;
    private JTextField txtLoanType, txtPrincipal, txtInterest, txtTerm, txtStart, txtEnd, txtStatus;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private int selectedId = -1;
    private String role;
	private int accountId;
	private int userId;
    public LoanPanel(String role, int userId, int accountId) {
    	this.role = role;
    	this.userId = userId;
    	this.accountId = accountId;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // ===== Title =====
        JLabel title = new JLabel("Loan Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // ===== Table =====
        model = new DefaultTableModel(new String[]{
                "LoanID", "AccountHolder", "LoanType", "Principal", "Interest", "Term", "Start", "End", "Status", "CreatedAt"
        }, 0);

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i >= 0) {
                    selectedId = Integer.parseInt(model.getValueAt(i, 0).toString());
                    cbAccountHolder.setSelectedItem(model.getValueAt(i, 1).toString());
                    txtLoanType.setText(model.getValueAt(i, 2).toString());
                    txtPrincipal.setText(model.getValueAt(i, 3).toString());
                    txtInterest.setText(model.getValueAt(i, 4).toString());
                    txtTerm.setText(model.getValueAt(i, 5).toString());
                    txtStart.setText(model.getValueAt(i, 6).toString());
                    txtEnd.setText(model.getValueAt(i, 7).toString());
                    txtStatus.setText(model.getValueAt(i, 8).toString());
                }
            }
        });
        JScrollPane scrollPane = new JScrollPane(table);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Loan Details"));
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Account Holder:"), gbc);
        gbc.gridx = 1; cbAccountHolder = new JComboBox<>(); loadAccountHolders(); formPanel.add(cbAccountHolder, gbc);

        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Loan Type:"), gbc);
        gbc.gridx = 1; txtLoanType = new JTextField(); formPanel.add(txtLoanType, gbc);

        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Principal Amount:"), gbc);
        gbc.gridx = 1; txtPrincipal = new JTextField(); formPanel.add(txtPrincipal, gbc);

        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Interest Rate (%):"), gbc);
        gbc.gridx = 1; txtInterest = new JTextField(); formPanel.add(txtInterest, gbc);

        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Term (Months):"), gbc);
        gbc.gridx = 1; txtTerm = new JTextField(); formPanel.add(txtTerm, gbc);

        gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("Start Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1; txtStart = new JTextField(); formPanel.add(txtStart, gbc);

        gbc.gridx = 0; gbc.gridy = 6; formPanel.add(new JLabel("End Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1; txtEnd = new JTextField(); formPanel.add(txtEnd, gbc);

        gbc.gridx = 0; gbc.gridy = 7; formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1; txtStatus = new JTextField(); formPanel.add(txtStatus, gbc);

        // ===== Buttons =====
        JPanel btnPanel = new JPanel(new GridLayout(2,2,5,5));
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnAdd.addActionListener(e -> addLoan());
        btnUpdate.addActionListener(e -> updateLoan());
        btnDelete.addActionListener(e -> deleteLoan());
        btnRefresh.addActionListener(e -> loadLoans());

        btnPanel.add(btnAdd); btnPanel.add(btnUpdate);
         btnPanel.add(btnRefresh);

        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2; formPanel.add(btnPanel, gbc);

        // ===== Split Pane =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, formPanel);
        splitPane.setResizeWeight(0.7);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        // Load data
        loadLoans();
    }

    // ===== Load Account Holders for ComboBox =====
    private void loadAccountHolders() {
        cbAccountHolder.removeAllItems();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT AccountHolderID, FullName FROM AccountHolder where AccountHolderID = '" + userId + "'")) {
            while (rs.next()) {
                cbAccountHolder.addItem(rs.getInt("AccountHolderID") + " - " + rs.getString("FullName"));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading account holders: " + ex.getMessage());
        }
    }

    // ===== Load All Loans =====
    private void loadLoans() {
        model.setRowCount(0);
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT Loan.LoanID, CONCAT(AccountHolder.AccountHolderID, ' - ', AccountHolder.FullName) AS Holder, " +
                             "LoanType, PrincipalAmount, InterestRate, TermMonths, StartDate, EndDate, Status, Loan.CreatedAt " +
                             "FROM Loan JOIN AccountHolder ON Loan.accountHolder_id = AccountHolder.AccountHolderID where accountHolder_id='" + userId + "'"+
                             " ORDER BY LoanID ASC")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("LoanID"),
                        rs.getString("Holder"),
                        rs.getString("LoanType"),
                        rs.getDouble("PrincipalAmount"),
                        rs.getDouble("InterestRate"),
                        rs.getInt("TermMonths"),
                        rs.getDate("StartDate"),
                        rs.getDate("EndDate"),
                        rs.getString("Status"),
                        rs.getTimestamp("CreatedAt")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading loans: " + ex.getMessage());
        }
    }

    // ===== Add Loan =====
    private void addLoan() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO Loan (accountHolder_id, LoanType, PrincipalAmount, InterestRate, TermMonths, StartDate, EndDate, Status, CreatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())")) {

            int accountHolderId = Integer.parseInt(cbAccountHolder.getSelectedItem().toString().split(" - ")[0]);
            ps.setInt(1, accountHolderId);
            ps.setString(2, txtLoanType.getText());
            ps.setDouble(3, Double.parseDouble(txtPrincipal.getText()));
            ps.setDouble(4, Double.parseDouble(txtInterest.getText()));
            ps.setInt(5, Integer.parseInt(txtTerm.getText()));
            ps.setDate(6, Date.valueOf(txtStart.getText()));
            ps.setDate(7, Date.valueOf(txtEnd.getText()));
            ps.setString(8, txtStatus.getText());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Loan added successfully!");
            loadLoans();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding loan: " + ex.getMessage());
        }
    }

    // ===== Update Loan =====
    private void updateLoan() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a loan to update!");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE Loan SET accountHolder_id=?, LoanType=?, PrincipalAmount=?, InterestRate=?, TermMonths=?, StartDate=?, EndDate=?, Status=? WHERE LoanID=?")) {

            int accountHolderId = Integer.parseInt(cbAccountHolder.getSelectedItem().toString().split(" - ")[0]);
            ps.setInt(1, accountHolderId);
            ps.setString(2, txtLoanType.getText());
            ps.setDouble(3, Double.parseDouble(txtPrincipal.getText()));
            ps.setDouble(4, Double.parseDouble(txtInterest.getText()));
            ps.setInt(5, Integer.parseInt(txtTerm.getText()));
            ps.setDate(6, Date.valueOf(txtStart.getText()));
            ps.setDate(7, Date.valueOf(txtEnd.getText()));
            ps.setString(8, txtStatus.getText());
            ps.setInt(9, selectedId);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Loan updated successfully!");
            loadLoans();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating loan: " + ex.getMessage());
        }
    }

    // ===== Delete Loan =====
    private void deleteLoan() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a loan to delete!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this loan?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM Loan WHERE LoanID=?")) {

            ps.setInt(1, selectedId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Loan deleted!");
            loadLoans();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting loan: " + ex.getMessage());
        }
    }

    // ===== Helper =====
    private void clearFields() {
        txtLoanType.setText("");
        txtPrincipal.setText("");
        txtInterest.setText("");
        txtTerm.setText("");
        txtStart.setText("");
        txtEnd.setText("");
        txtStatus.setText("");
        selectedId = -1;
    }
}
