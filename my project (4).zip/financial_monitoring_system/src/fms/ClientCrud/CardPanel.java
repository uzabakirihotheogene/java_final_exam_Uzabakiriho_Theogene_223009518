package fms.ClientCrud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class CardPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<String> cbBranch, cbCardHolder;
    private JTextField txtCardNumber, txtCardType, txtExpiryDate, txtCVV, txtStatus;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private int selectedId = -1;
    private String role;
	private int accountId;
	private int userId;
    public CardPanel(String role, int userId, int accountId) {
    	this.role = role;
    	this.userId = userId;
    	this.accountId = accountId;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // ===== Title =====
        JLabel title = new JLabel("Card Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // ===== Table =====
        model = new DefaultTableModel(new String[]{
                "CardID", "Branch", "Card Holder", "Card Number", "Card Type", "Expiry Date", "CVV", "Status", "Created At"
        }, 0);

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i >= 0) {
                    selectedId = Integer.parseInt(model.getValueAt(i, 0).toString());
                    cbBranch.setSelectedItem(model.getValueAt(i, 1).toString());
                    cbCardHolder.setSelectedItem(model.getValueAt(i, 2).toString());
                    txtCardNumber.setText(model.getValueAt(i, 3).toString());
                    txtCardType.setText(model.getValueAt(i, 4).toString());
                    txtExpiryDate.setText(model.getValueAt(i, 5).toString());
                    txtCVV.setText(model.getValueAt(i, 6).toString());
                    txtStatus.setText(model.getValueAt(i, 7).toString());
                }
            }
        });
        JScrollPane scrollPane = new JScrollPane(table);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Card Details"));
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Branch:"), gbc);
        gbc.gridx = 1; cbBranch = new JComboBox<>(); loadBranches(); formPanel.add(cbBranch, gbc);

        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Card Holder:"), gbc);
        gbc.gridx = 1; cbCardHolder = new JComboBox<>(); loadCardHolders(); formPanel.add(cbCardHolder, gbc);

        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Card Number:"), gbc);
        gbc.gridx = 1; txtCardNumber = new JTextField(); formPanel.add(txtCardNumber, gbc);

        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Card Type:"), gbc);
        gbc.gridx = 1; txtCardType = new JTextField(); formPanel.add(txtCardType, gbc);

        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Expiry Date (YYYY-MM-DD):"), gbc);
        gbc.gridx = 1; txtExpiryDate = new JTextField(); formPanel.add(txtExpiryDate, gbc);

        gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("CVV:"), gbc);
        gbc.gridx = 1; txtCVV = new JTextField(); formPanel.add(txtCVV, gbc);

        gbc.gridx = 0; gbc.gridy = 6; formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1; txtStatus = new JTextField(); formPanel.add(txtStatus, gbc);

        // ===== Buttons =====
        JPanel btnPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnAdd.addActionListener(e -> addCard());
        btnUpdate.addActionListener(e -> updateCard());
        btnDelete.addActionListener(e -> deleteCard());
        btnRefresh.addActionListener(e -> loadCards());


        gbc.gridx = 0; gbc.gridy = 7; gbc.gridwidth = 2; formPanel.add(btnPanel, gbc);

        // ===== Split Pane =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, formPanel);
        splitPane.setResizeWeight(0.7);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        loadCards();
    }

    // ===== Load Branches =====
    private void loadBranches() {
        cbBranch.removeAllItems();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT BranchID, Name FROM Branch")) {
            while (rs.next()) {
                cbBranch.addItem(rs.getInt("BranchID") + " - " + rs.getString("Name"));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading branches: " + ex.getMessage());
        }
    }

    // ===== Load Card Holders =====
    private void loadCardHolders() {
        cbCardHolder.removeAllItems();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT AccountHolderID, FullName FROM AccountHolder")) {
            while (rs.next()) {
                cbCardHolder.addItem(rs.getInt("AccountHolderID") + " - " + rs.getString("FullName"));
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading card holders: " + ex.getMessage());
        }
    }

    // ===== Load All Cards =====
    private void loadCards() {
        model.setRowCount(0);
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT a.*, c.CardID, CONCAT(b.BranchID, ' - ', b.Name) AS Branch, " +
                             "CONCAT(a.AccountHolderID, ' - ', a.FullName) AS Holder, " +
                             "c.CardNumber, c.CardType, c.ExpiryDate, c.CVV, c.Status, c.CreatedAt " +
                             "FROM Card c " +
                             "JOIN Branch b ON c.branch_id = b.BranchID " +
                             "JOIN AccountHolder a ON c.card_holder = a.AccountHolderID  where c.card_holder='" + userId + "'" +
                             " ORDER BY c.CardID ASC")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("CardID"),
                        rs.getString("Branch"),
                        rs.getString("Holder"),
                        rs.getString("CardNumber"),
                        rs.getString("CardType"),
                        rs.getDate("ExpiryDate"),
                        rs.getString("CVV"),
                        rs.getString("Status"),
                        rs.getTimestamp("CreatedAt")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading cards: " + ex.getMessage());
        }
    }

    // ===== Add Card =====
    private void addCard() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO Card (branch_id, card_holder, CardNumber, CardType, ExpiryDate, CVV, Status, CreatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())")) {

            int branchId = Integer.parseInt(cbBranch.getSelectedItem().toString().split(" - ")[0]);
            int holderId = Integer.parseInt(cbCardHolder.getSelectedItem().toString().split(" - ")[0]);
            ps.setInt(1, branchId);
            ps.setInt(2, holderId);
            ps.setString(3, txtCardNumber.getText());
            ps.setString(4, txtCardType.getText());
            ps.setDate(5, Date.valueOf(txtExpiryDate.getText()));
            ps.setString(6, txtCVV.getText());
            ps.setString(7, txtStatus.getText());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Card added successfully!");
            loadCards();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding card: " + ex.getMessage());
        }
    }

    // ===== Update Card =====
    private void updateCard() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a card to update!");
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE Card SET branch_id=?, card_holder=?, CardNumber=?, CardType=?, ExpiryDate=?, CVV=?, Status=? WHERE CardID=?")) {

            int branchId = Integer.parseInt(cbBranch.getSelectedItem().toString().split(" - ")[0]);
            int holderId = Integer.parseInt(cbCardHolder.getSelectedItem().toString().split(" - ")[0]);
            ps.setInt(1, branchId);
            ps.setInt(2, holderId);
            ps.setString(3, txtCardNumber.getText());
            ps.setString(4, txtCardType.getText());
            ps.setDate(5, Date.valueOf(txtExpiryDate.getText()));
            ps.setString(6, txtCVV.getText());
            ps.setString(7, txtStatus.getText());
            ps.setInt(8, selectedId);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Card updated successfully!");
            loadCards();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating card: " + ex.getMessage());
        }
    }

    // ===== Delete Card =====
    private void deleteCard() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a card to delete!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this card?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM Card WHERE CardID=?")) {

            ps.setInt(1, selectedId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Card deleted!");
            loadCards();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting card: " + ex.getMessage());
        }
    }

    // ===== Helper =====
    private void clearFields() {
        txtCardNumber.setText("");
        txtCardType.setText("");
        txtExpiryDate.setText("");
        txtCVV.setText("");
        txtStatus.setText("");
        selectedId = -1;
    }
}