package fms.ClientCrud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class TransactionPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtLoanId, txtTotalAmount, txtPaymentMethod, txtNotes;
    private JComboBox<String> comboStatus, comboType;
    private JButton btnAdd, btnRefresh;
    private int selectedId = -1;

    private String role;
    private int accountId;
    private int userId;

    public TransactionPanel(String role, int userId, int accountId) {
        this.role = role;
        this.userId = userId;
        this.accountId = accountId;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel title = new JLabel("Transaction Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // ===== Table Panel =====
        model = new DefaultTableModel(new String[]{
                "ID", "Date", "Loan ID", "Status", "Amount", "Type", "Payment Method", "Notes"
        }, 0);

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane tableScroll = new JScrollPane(table);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createTitledBorder("Transaction Details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;

        // Loan ID
        gbc.gridx = 0; gbc.gridy = y; formPanel.add(new JLabel("Loan ID:"), gbc);
        gbc.gridx = 1; txtLoanId = new JTextField(); formPanel.add(txtLoanId, gbc);

        // Status (Hidden, Always Pending)
        comboStatus = new JComboBox<>();
        comboStatus.addItem("pending");
        comboStatus.setVisible(false);

        // Total Amount
        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Total Amount:"), gbc);
        gbc.gridx = 1; txtTotalAmount = new JTextField(); formPanel.add(txtTotalAmount, gbc);

        // Type
        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Type:"), gbc);
        gbc.gridx = 1; comboType = new JComboBox<>(new String[]{
                "deposit", "withdraw", "repayment", "loan disbursement", "loan repayment"
        });
        formPanel.add(comboType, gbc);

        // Payment Method
        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Payment Method:"), gbc);
        gbc.gridx = 1; txtPaymentMethod = new JTextField(); formPanel.add(txtPaymentMethod, gbc);

        // Notes
        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Notes:"), gbc);
        gbc.gridx = 1; txtNotes = new JTextField(); formPanel.add(txtNotes, gbc);

        // ===== Buttons =====
        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 5, 5));
        btnAdd = new JButton("Add");
        btnRefresh = new JButton("Refresh");

        btnAdd.addActionListener(e -> addTransaction());
        btnRefresh.addActionListener(e -> loadTransactions());

        btnPanel.add(btnAdd);
        btnPanel.add(btnRefresh);

        gbc.gridx = 0; gbc.gridy = ++y; gbc.gridwidth = 2;
        formPanel.add(btnPanel, gbc);

        // ===== Split Pane =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, formPanel);
        splitPane.setResizeWeight(0.7);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        loadTransactions();
    }

    // ===== Load Transactions =====
    private void loadTransactions() {
        model.setRowCount(0);
        String sql = "SELECT * FROM transaction WHERE accountId = '" + accountId + "'";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("TransactionID"),
                        rs.getTimestamp("Date"),
                        rs.getObject("LoanId"),
                        rs.getString("Status"),
                        rs.getDouble("TotalAmount"),
                        rs.getString("Type"),
                        rs.getString("PaymentMethod"),
                        rs.getString("Notes")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading transactions: " + ex.getMessage());
        }
    }

    // ===== Add Transaction =====
    private void addTransaction() {

        String sql = "INSERT INTO transaction (OrderNumber, Date, accountId, loanId, Status, TotalAmount, Type, PaymentMethod, Notes) " +
                "VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, ""); // Order number removed
            ps.setInt(2, accountId); // Always use passed accountId

            if (txtLoanId.getText().isEmpty()) ps.setNull(3, Types.INTEGER);
            else ps.setInt(3, Integer.parseInt(txtLoanId.getText()));

            ps.setString(4, "pending"); // Always pending
            ps.setDouble(5, Double.parseDouble(txtTotalAmount.getText()));
            ps.setString(6, comboType.getSelectedItem().toString());
            ps.setString(7, txtPaymentMethod.getText());
            ps.setString(8, txtNotes.getText());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Transaction added successfully!");

            loadTransactions();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding transaction: " + ex.getMessage());
        }
    }

    // ===== Clear Fields =====
    private void clearFields() {
        txtLoanId.setText("");
        txtTotalAmount.setText("");
        txtPaymentMethod.setText("");
        txtNotes.setText("");
        comboType.setSelectedIndex(0);
        selectedId = -1;
    }
}