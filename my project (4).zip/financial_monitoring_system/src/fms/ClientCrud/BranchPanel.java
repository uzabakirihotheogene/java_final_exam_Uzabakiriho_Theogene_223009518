// Fully Modified BranchPanel with ALL action buttons removed
package fms.ClientCrud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class BranchPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtName, txtAddress, txtCapacity, txtManager, txtContact;
    private int selectedId = -1;
    private String role;
    private int accountId;
    private int userId;

    public BranchPanel(String role, int userId, int accountId) {
        this.role = role;
        this.userId = userId;
        this.accountId = accountId;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel title = new JLabel("Branch Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        model = new DefaultTableModel(
                new String[]{"ID", "Name", "Address", "Capacity", "Manager", "Contact"}, 
                0
        );
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i >= 0) {
                    selectedId = Integer.parseInt(model.getValueAt(i, 0).toString());
                    txtName.setText(model.getValueAt(i, 1).toString());
                    txtAddress.setText(model.getValueAt(i, 2).toString());
                    txtCapacity.setText(model.getValueAt(i, 3).toString());
                    txtManager.setText(model.getValueAt(i, 4).toString());
                    txtContact.setText(model.getValueAt(i, 5).toString());
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Branch Details"));
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; 
        txtName = new JTextField();
        txtName.setEditable(false);
        formPanel.add(txtName, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1; 
        txtAddress = new JTextField();
        txtAddress.setEditable(false);
        formPanel.add(txtAddress, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 1; 
        txtCapacity = new JTextField();
        txtCapacity.setEditable(false);
        formPanel.add(txtCapacity, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Manager:"), gbc);
        gbc.gridx = 1; 
        txtManager = new JTextField();
        txtManager.setEditable(false);
        formPanel.add(txtManager, gbc);

        gbc.gridx = 0; gbc.gridy = 4;
        formPanel.add(new JLabel("Contact:"), gbc);
        gbc.gridx = 1; 
        txtContact = new JTextField();
        txtContact.setEditable(false);
        formPanel.add(txtContact, gbc);

        // No buttons added here

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT, 
                scrollPane, 
                formPanel
        );
        splitPane.setResizeWeight(0.65);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        loadBranches();
    }

    private void loadBranches() {
        model.setRowCount(0);
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT * FROM Branch b INNER JOIN account a ON a.branch_id=b.BranchID " +
                     "WHERE a.AccountID='" + accountId + "' ORDER BY BranchID ASC"
             )) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("BranchID"),
                        rs.getString("Name"),
                        rs.getString("Address"),
                        rs.getInt("Capacity"),
                        rs.getString("Manager"),
                        rs.getString("Contact")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading branches: " + ex.getMessage());
        }
    }
}
