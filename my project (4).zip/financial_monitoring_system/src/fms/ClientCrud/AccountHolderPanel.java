package fms.ClientCrud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class AccountHolderPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtUsername, txtEmail, txtFullName, txtRole;
    private JPasswordField txtPassword;
    private JButton btnUpdate, btnRefresh;

    private int selectedId = -1; 
    private String role;
    private int accountId;
    private int userId;

    public AccountHolderPanel(String role, int userId, int accountId) {
        this.role = role;
        this.userId = userId;
        this.accountId = accountId;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel title = new JLabel("Account Holder Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Username", "Email", "Full Name", "Role", "Created At"}, 0);
        table = new JTable(model);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i >= 0) {
                    selectedId = Integer.parseInt(model.getValueAt(i, 0).toString());
                    txtUsername.setText(model.getValueAt(i, 1).toString());
                    txtEmail.setText(model.getValueAt(i, 2).toString());
                    txtFullName.setText(model.getValueAt(i, 3).toString());
                    txtRole.setText(model.getValueAt(i, 4).toString());
                }
            }
        });

        JScrollPane tableScroll = new JScrollPane(table);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Account Holder Details"));
        formPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1; txtUsername = new JTextField(); formPanel.add(txtUsername, gbc);

        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1; txtPassword = new JPasswordField(); formPanel.add(txtPassword, gbc);

        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; txtEmail = new JTextField(); formPanel.add(txtEmail, gbc);

        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1; txtFullName = new JTextField(); formPanel.add(txtFullName, gbc);

        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Role:"), gbc);
        gbc.gridx = 1; txtRole = new JTextField(); formPanel.add(txtRole, gbc);

        // NEW: Only Update and Refresh
        JPanel btnPanel = new JPanel(new GridLayout(1,2,5,5));
        btnUpdate = new JButton("Update");
        btnRefresh = new JButton("Refresh");

        btnUpdate.addActionListener(e -> updateAccountHolder());
        btnRefresh.addActionListener(e -> loadAccountHolders());

        btnPanel.add(btnUpdate);
        btnPanel.add(btnRefresh);

        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        formPanel.add(btnPanel, gbc);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, formPanel);
        splitPane.setResizeWeight(0.65);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        loadAccountHolders();
    }

    private void loadAccountHolders() {
        model.setRowCount(0);

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT AccountHolderID, Username, Email, FullName, Role, CreatedAt " +
                     "FROM AccountHolder WHERE AccountHolderID='" + userId + "'")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("AccountHolderID"),
                        rs.getString("Username"),
                        rs.getString("Email"),
                        rs.getString("FullName"),
                        rs.getString("Role"),
                        rs.getString("CreatedAt")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    private void updateAccountHolder() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a record to update!");
            return;
        }

        String sql = "UPDATE AccountHolder SET Username=?, Email=?, FullName=?, Role=? WHERE AccountHolderID=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtUsername.getText());
            ps.setString(2, txtEmail.getText());
            ps.setString(3, txtFullName.getText());
            ps.setString(4, txtRole.getText());
            ps.setInt(5, selectedId);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Account Holder updated successfully!");
            loadAccountHolders();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating: " + ex.getMessage());
        }
    }

    private void clearFields() {
        txtUsername.setText("");
        txtPassword.setText("");
        txtEmail.setText("");
        txtFullName.setText("");
        txtRole.setText("");
        selectedId = -1;
    }
}
