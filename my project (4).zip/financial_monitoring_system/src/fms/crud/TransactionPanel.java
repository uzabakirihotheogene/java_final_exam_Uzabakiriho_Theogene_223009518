package fms.crud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class TransactionPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtOrderNumber, txtAccountId, txtLoanId, txtTotalAmount, txtPaymentMethod, txtNotes;
    private JComboBox<String> comboStatus, comboType;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private int selectedId = -1;

    public TransactionPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        JLabel title = new JLabel("Transaction Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // ===== Table Panel =====
        model = new DefaultTableModel(new String[]{
                "ID", "Order Number", "Date", "Account ID", "Loan ID",
                "Status", "Amount", "Type", "Payment Method", "Notes"
        }, 0);
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i >= 0) {
                    selectedId = Integer.parseInt(model.getValueAt(i, 0).toString());
                    txtOrderNumber.setText(model.getValueAt(i, 1).toString());
                    txtAccountId.setText(model.getValueAt(i, 3).toString());
                    txtLoanId.setText(model.getValueAt(i, 4) == null ? "" : model.getValueAt(i, 4).toString());
                    comboStatus.setSelectedItem(model.getValueAt(i, 5).toString());
                    txtTotalAmount.setText(model.getValueAt(i, 6).toString());
                    comboType.setSelectedItem(model.getValueAt(i, 7).toString());
                    txtPaymentMethod.setText(model.getValueAt(i, 8).toString());
                    txtNotes.setText(model.getValueAt(i, 9).toString());
                }
            }
        });
        JScrollPane tableScroll = new JScrollPane(table);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createTitledBorder("Transaction Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; formPanel.add(new JLabel("Order Number:"), gbc);
        gbc.gridx = 1; txtOrderNumber = new JTextField(); formPanel.add(txtOrderNumber, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Account ID:"), gbc);
        gbc.gridx = 1; txtAccountId = new JTextField(); formPanel.add(txtAccountId, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Loan ID:"), gbc);
        gbc.gridx = 1; txtLoanId = new JTextField(); formPanel.add(txtLoanId, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1; comboStatus = new JComboBox<>(new String[]{"pending", "completed", "failed"});
        formPanel.add(comboStatus, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Total Amount:"), gbc);
        gbc.gridx = 1; txtTotalAmount = new JTextField(); formPanel.add(txtTotalAmount, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Type:"), gbc);
        gbc.gridx = 1; comboType = new JComboBox<>(new String[]{
                "deposit", "withdraw", "repayment", "loan disbursement", "loan repayment"
        });
        formPanel.add(comboType, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Payment Method:"), gbc);
        gbc.gridx = 1; txtPaymentMethod = new JTextField(); formPanel.add(txtPaymentMethod, gbc);

        gbc.gridx = 0; gbc.gridy = ++y; formPanel.add(new JLabel("Notes:"), gbc);
        gbc.gridx = 1; txtNotes = new JTextField(); formPanel.add(txtNotes, gbc);

        // ===== Buttons =====
        JPanel btnPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnAdd.addActionListener(e -> addTransaction());
        btnUpdate.addActionListener(e -> updateTransaction());
        btnDelete.addActionListener(e -> deleteTransaction());
        btnRefresh.addActionListener(e -> loadTransactions());

        btnPanel.add(btnAdd); btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete); btnPanel.add(btnRefresh);

        gbc.gridx = 0; gbc.gridy = ++y; gbc.gridwidth = 2;
        formPanel.add(btnPanel, gbc);

        // ===== Split Pane =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, formPanel);
        splitPane.setResizeWeight(0.7);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        loadTransactions();
    }

    // ===== Load Transactions =====
    private void loadTransactions() {
        model.setRowCount(0);
        String sql = "SELECT * FROM transaction";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("TransactionID"),
                        rs.getString("OrderNumber"),
                        rs.getTimestamp("Date"),
                        rs.getInt("accountId"),
                        rs.getObject("loanId"),
                        rs.getString("Status"),
                        rs.getDouble("TotalAmount"),
                        rs.getString("Type"),
                        rs.getString("PaymentMethod"),
                        rs.getString("Notes")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading transactions: " + ex.getMessage());
        }
    }

    // ===== Add Transaction =====
    private void addTransaction() {
        if (txtOrderNumber.getText().isEmpty() || txtAccountId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Order Number and Account ID are required!");
            return;
        }

        String sql = "INSERT INTO transaction (OrderNumber, Date, accountId, loanId, Status, TotalAmount, Type, PaymentMethod, Notes) " +
                "VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtOrderNumber.getText());
            ps.setInt(2, Integer.parseInt(txtAccountId.getText()));
            if (txtLoanId.getText().isEmpty()) ps.setNull(3, Types.INTEGER);
            else ps.setInt(3, Integer.parseInt(txtLoanId.getText()));
            ps.setString(4, comboStatus.getSelectedItem().toString());
            ps.setDouble(5, Double.parseDouble(txtTotalAmount.getText()));
            ps.setString(6, comboType.getSelectedItem().toString());
            ps.setString(7, txtPaymentMethod.getText());
            ps.setString(8, txtNotes.getText());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Transaction added successfully!");
            loadTransactions();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding transaction: " + ex.getMessage());
        }
    }

    // ===== Update Transaction =====
    private void updateTransaction() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a transaction to update!");
            return;
        }

        String sql = "UPDATE transaction SET OrderNumber=?, accountId=?, loanId=?, Status=?, TotalAmount=?, Type=?, PaymentMethod=?, Notes=? WHERE TransactionID=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtOrderNumber.getText());
            ps.setInt(2, Integer.parseInt(txtAccountId.getText()));
            if (txtLoanId.getText().isEmpty()) ps.setNull(3, Types.INTEGER);
            else ps.setInt(3, Integer.parseInt(txtLoanId.getText()));
            ps.setString(4, comboStatus.getSelectedItem().toString());
            ps.setDouble(5, Double.parseDouble(txtTotalAmount.getText()));
            ps.setString(6, comboType.getSelectedItem().toString());
            ps.setString(7, txtPaymentMethod.getText());
            ps.setString(8, txtNotes.getText());
            ps.setInt(9, selectedId);

            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Transaction updated successfully!");
            loadTransactions();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating transaction: " + ex.getMessage());
        }
    }

    // ===== Delete Transaction =====
    private void deleteTransaction() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a transaction to delete!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this transaction?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM transaction WHERE TransactionID=?")) {

            ps.setInt(1, selectedId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Transaction deleted!");
            loadTransactions();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting transaction: " + ex.getMessage());
        }
    }

    // ===== Clear Fields =====
    private void clearFields() {
        txtOrderNumber.setText("");
        txtAccountId.setText("");
        txtLoanId.setText("");
        txtTotalAmount.setText("");
        txtPaymentMethod.setText("");
        txtNotes.setText("");
        comboStatus.setSelectedIndex(0);
        comboType.setSelectedIndex(0);
        selectedId = -1;
    }
}
