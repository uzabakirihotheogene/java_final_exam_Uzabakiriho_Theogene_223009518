package fms.crud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class AccountPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtBranchId, txtAccNum;
    private JComboBox<AccountHolderItem> comboAccountHolder;
    private JComboBox<String> comboStatus;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;

    private int selectedId = -1; // selected AccountID

    public AccountPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // ===== Title =====
        JLabel title = new JLabel("Account Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
        add(title, BorderLayout.NORTH);

        // ===== Table Panel (Left 65%) =====
        model = new DefaultTableModel(new String[]{"ID", "Branch ID", "Account Holder", "Account Number", "Status", "Created At"},0);
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if(i >= 0){
                    selectedId = Integer.parseInt(model.getValueAt(i,0).toString());
                    txtBranchId.setText(model.getValueAt(i,1).toString());
                    comboAccHolderSelect(model.getValueAt(i,2).toString());
                    txtAccNum.setText(model.getValueAt(i,3).toString());
                    comboStatus.setSelectedItem(model.getValueAt(i,4).toString());
                }
            }
        });
        JScrollPane tableScroll = new JScrollPane(table);

        // ===== Form Panel (Right 35%) =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Account Details"));
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx=0; gbc.gridy=0; formPanel.add(new JLabel("Branch ID:"), gbc);
        gbc.gridx=1; txtBranchId = new JTextField(); formPanel.add(txtBranchId, gbc);

        gbc.gridx=0; gbc.gridy=1; formPanel.add(new JLabel("Account Holder:"), gbc);
        gbc.gridx=1; 
        comboAccountHolder = new JComboBox<>();
        loadAccountHoldersCombo();
        formPanel.add(comboAccountHolder, gbc);

        gbc.gridx=0; gbc.gridy=2; formPanel.add(new JLabel("Account Number:"), gbc);
        gbc.gridx=1; txtAccNum = new JTextField(); formPanel.add(txtAccNum, gbc);

        gbc.gridx=0; gbc.gridy=3; formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx=1; comboStatus = new JComboBox<>(new String[]{"active","inactive","closed"});
        formPanel.add(comboStatus, gbc);

        // ===== Button Panel =====
        JPanel btnPanel = new JPanel(new GridLayout(2,2,5,5));
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnAdd.addActionListener(e -> addAccount());
        btnUpdate.addActionListener(e -> updateAccount());
        btnDelete.addActionListener(e -> deleteAccount());
        btnRefresh.addActionListener(e -> loadAccounts());

        btnPanel.add(btnAdd); btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete); btnPanel.add(btnRefresh);

        gbc.gridx=0; gbc.gridy=4; gbc.gridwidth=2; formPanel.add(btnPanel, gbc);

        // ===== Split Pane =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScroll, formPanel);
        splitPane.setResizeWeight(0.65);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        loadAccounts();
    }

    // ===== Load Account Holders for combo box =====
    private void loadAccountHoldersCombo() {
        comboAccountHolder.removeAllItems();
        try(Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT AccountHolderID, FullName FROM AccountHolder")) {

            while(rs.next()){
                comboAccountHolder.addItem(new AccountHolderItem(rs.getInt("AccountHolderID"), rs.getString("FullName")));
            }

        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error loading account holders: "+ex.getMessage());
        }
    }

    // helper to select account holder in combo based on name
    private void comboAccHolderSelect(String name){
        for(int i=0;i<comboAccountHolder.getItemCount();i++){
            if(comboAccountHolder.getItemAt(i).toString().equals(name)){
                comboAccountHolder.setSelectedIndex(i);
                return;
            }
        }
    }

    // ===== Load Accounts =====
    private void loadAccounts(){
        model.setRowCount(0);
        String sql = "SELECT a.AccountID, a.branch_id, ah.FullName AS account_holder, a.account_number, a.status, a.CreatedAt " +
                     "FROM account a LEFT JOIN AccountHolder ah ON a.account_holder_id=ah.AccountHolderID";
        try(Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql)) {

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("AccountID"),
                        rs.getInt("branch_id"),
                        rs.getString("account_holder"),
                        rs.getString("account_number"),
                        rs.getString("status"),
                        rs.getString("CreatedAt")
                });
            }

        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error loading accounts: "+ex.getMessage());
        }
    }

    // ===== Add Account =====
    private void addAccount(){
        if(txtBranchId.getText().isEmpty() || txtAccNum.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Branch ID and Account Number required!");
            return;
        }
        String sql = "INSERT INTO account (branch_id, account_holder_id, account_number, status, CreatedAt) VALUES (?,?,?,?,NOW())";
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtBranchId.getText()));
            ps.setInt(2, ((AccountHolderItem)comboAccountHolder.getSelectedItem()).getId());
            ps.setString(3, txtAccNum.getText());
            ps.setString(4, comboStatus.getSelectedItem().toString());
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Account added successfully!");
            loadAccounts();
            clearFields();

        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error adding account: "+ex.getMessage());
        }
    }

    // ===== Update Account =====
    private void updateAccount(){
        if(selectedId == -1){
            JOptionPane.showMessageDialog(this,"Select account to update!");
            return;
        }
        String sql = "UPDATE account SET branch_id=?, account_holder_id=?, account_number=?, status=? WHERE AccountID=?";
        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(txtBranchId.getText()));
            ps.setInt(2, ((AccountHolderItem)comboAccountHolder.getSelectedItem()).getId());
            ps.setString(3, txtAccNum.getText());
            ps.setString(4, comboStatus.getSelectedItem().toString());
            ps.setInt(5, selectedId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,"Account updated successfully!");
            loadAccounts();
            clearFields();

        } catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error updating account: "+ex.getMessage());
        }
    }

    // ===== Delete Account =====
    private void deleteAccount(){
        if(selectedId==-1){
            JOptionPane.showMessageDialog(this,"Select account to delete!");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this account?","Confirm",JOptionPane.YES_NO_OPTION);
        if(confirm != JOptionPane.YES_OPTION) return;

        try(Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM account WHERE AccountID=?")){

            ps.setInt(1, selectedId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this,"Account deleted!");
            loadAccounts();
            clearFields();

        } catch(Exception ex){
            JOptionPane.showMessageDialog(this,"Error deleting account: "+ex.getMessage());
        }
    }

    // ===== Clear Fields =====
    private void clearFields(){
        txtBranchId.setText("");
        txtAccNum.setText("");
        comboAccountHolder.setSelectedIndex(0);
        comboStatus.setSelectedIndex(0);
        selectedId=-1;
    }

    // ===== Helper class for combo box =====
    private static class AccountHolderItem {
        private int id;
        private String name;
        public AccountHolderItem(int id, String name){ this.id=id; this.name=name; }
        public int getId(){ return id; }
        public String toString(){ return name; }
    }
}
