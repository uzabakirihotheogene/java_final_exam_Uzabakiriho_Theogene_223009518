package fms.ClientDashboard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame implements ActionListener {
	private String role;
	private int accountId;
	private int userId;
    // Navigation buttons
    JButton ProfileBtn = new JButton("Profile");
    JButton accountBtn = new JButton("Account");
    JButton transactionBtn = new JButton("Transactions");
    JButton loanBtn = new JButton("Loans");
    JButton branchBtn = new JButton("Branch");
    JButton cardBtn = new JButton("Card");
    JButton logoutBtn = new JButton("Logout");

    // Main content area
    JPanel contentPanel = new JPanel();

    public Dashboard(String role, int userId, int accountId) {  
    	this.role = role;
    	this.userId = userId;
    	this.accountId = accountId;
    	
        setTitle("Finance Monitoring System - Client Portal");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ===== Header / Navbar =====
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        navPanel.setBackground(new Color(173, 216, 230));

        JButton[] buttons = {ProfileBtn, accountBtn, transactionBtn, loanBtn, branchBtn, cardBtn, logoutBtn};
        for (JButton btn : buttons) {
            btn.setPreferredSize(new Dimension(140, 35));
            btn.setBackground(new Color(224, 255, 255));
            btn.setFocusPainted(false);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btn.addActionListener(this);
            navPanel.add(btn);
        }

        // ===== Content Area =====
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);

        // Initial content (welcome message)
        JLabel welcome = new JLabel("Welcome to Finance Monitoring System", SwingConstants.CENTER);
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        contentPanel.add(welcome, BorderLayout.CENTER);

        // ===== Add to Frame =====
        add(navPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == logoutBtn) {
            int confirm = JOptionPane.showConfirmDialog(this, "Logout from system?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
            	dispose();
            	new fms.login.Loginform();
            	}
            return;
        }

        // Clear content panel first
        contentPanel.removeAll();

        if (src == ProfileBtn) {
            contentPanel.add(new fms.ClientCrud.AccountHolderPanel(role, userId, accountId), BorderLayout.CENTER);
        } else if (src == accountBtn) {
            contentPanel.add(new fms.ClientCrud.AccountPanel(role, userId, accountId), BorderLayout.CENTER);
        } else if (src == transactionBtn) {
            contentPanel.add(new fms.ClientCrud.TransactionPanel(role, userId, accountId), BorderLayout.CENTER);
        } else if (src == loanBtn) {
            contentPanel.add(new fms.ClientCrud.LoanPanel(role, userId, accountId), BorderLayout.CENTER);
        } else if (src == branchBtn) {
            contentPanel.add(new fms.ClientCrud.BranchPanel(role, userId, accountId), BorderLayout.CENTER);
        } else if (src == cardBtn) {
            contentPanel.add(new fms.ClientCrud.CardPanel(role, userId, accountId), BorderLayout.CENTER);
        }

        // Refresh content area
        contentPanel.revalidate();
        contentPanel.repaint();
    }
}
