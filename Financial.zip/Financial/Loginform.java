package fms.login;

import DB.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Loginform extends JFrame implements ActionListener {
    // Define components
    JLabel userLb = new JLabel("Username");
    JLabel passLb = new JLabel("Password");

    JTextField usertxt = new JTextField();
    JPasswordField passtxt = new JPasswordField();

    JButton loginbtn = new JButton("Login");
    JButton clientLogin = new JButton("Client");
    JButton cancelbtn = new JButton("Cancel");

    public Loginform() {
        setTitle("Login - fms app");
        setBounds(100, 200, 400, 200);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        userLb.setBounds(30, 30, 80, 25);
        usertxt.setBounds(120, 30, 120, 25);

        passLb.setBounds(30, 70, 80, 25);
        passtxt.setBounds(120, 70, 120, 25);

        loginbtn.setBounds(30, 120, 90, 30);
        clientLogin.setBounds(150, 120, 90, 30);
        cancelbtn.setBounds(270, 120, 90, 30);

        add(userLb);
        add(passLb);
        add(usertxt);
        add(passtxt);
        add(loginbtn);
        add(clientLogin);
        add(cancelbtn);
        
        loginbtn.addActionListener(this);
        clientLogin.addActionListener(this);
        cancelbtn.addActionListener(this);

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginbtn) {
            String user = usertxt.getText();
            String password = new String(passtxt.getPassword());

            try (Connection con = DBConnection.getConnection()) {
                String sql = "SELECT * FROM user WHERE username = ? AND password = ?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, user);
                pst.setString(2, password);

                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                    String role = rs.getNString("role");
                    int userId = rs.getInt("id");
                    //new SMIS(role,userId);
                    new fms.dashboard.Dashboard(role, userId);
                    
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Username or Password", "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (e.getSource() == cancelbtn) {
            int confirm = JOptionPane.showConfirmDialog(this, "Exit Application?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) System.exit(0);
        }else if (e.getSource() == clientLogin) {
        	dispose();
        	new fms.login.ClientLogin();
        }
        
    }
    public static void main(String[] args) {
    	new Loginform();
    }
}
