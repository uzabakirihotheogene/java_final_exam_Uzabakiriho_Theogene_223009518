package fms.crud;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import DB.DBConnection;

public class BranchPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtName, txtAddress, txtCapacity, txtManager, txtContact;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    private int selectedId = -1;

    public BranchPanel() {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // ===== Title =====
        JLabel title = new JLabel("Branch Management", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(title, BorderLayout.NORTH);

        // ===== Table =====
        model = new DefaultTableModel(new String[]{"ID", "Name", "Address", "Capacity", "Manager", "Contact"}, 0);
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i >= 0) {
                    selectedId = Integer.parseInt(model.getValueAt(i, 0).toString());
                    txtName.setText(model.getValueAt(i, 1).toString());
                    txtAddress.setText(model.getValueAt(i, 2).toString());
                    txtCapacity.setText(model.getValueAt(i, 3).toString());
                    txtManager.setText(model.getValueAt(i, 4).toString());
                    txtContact.setText(model.getValueAt(i, 5).toString());
                }
            }
        });
        JScrollPane scrollPane = new JScrollPane(table);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Branch Details"));
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; txtName = new JTextField(); formPanel.add(txtName, gbc);

        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1; txtAddress = new JTextField(); formPanel.add(txtAddress, gbc);

        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 1; txtCapacity = new JTextField(); formPanel.add(txtCapacity, gbc);

        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Manager:"), gbc);
        gbc.gridx = 1; txtManager = new JTextField(); formPanel.add(txtManager, gbc);

        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Contact:"), gbc);
        gbc.gridx = 1; txtContact = new JTextField(); formPanel.add(txtContact, gbc);

        // ===== Buttons =====
        JPanel btnPanel = new JPanel(new GridLayout(2,2,5,5));
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");

        btnAdd.addActionListener(e -> addBranch());
        btnUpdate.addActionListener(e -> updateBranch());
        btnDelete.addActionListener(e -> deleteBranch());
        btnRefresh.addActionListener(e -> loadBranches());

        btnPanel.add(btnAdd); btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete); btnPanel.add(btnRefresh);

        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2; formPanel.add(btnPanel, gbc);

        // ===== Split Pane =====
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, formPanel);
        splitPane.setResizeWeight(0.65);
        splitPane.setDividerSize(6);
        add(splitPane, BorderLayout.CENTER);

        // Load data on startup
        loadBranches();
    }

    // ===== Load All Branches =====
    private void loadBranches() {
        model.setRowCount(0);
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Branch ORDER BY BranchID ASC")) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("BranchID"),
                        rs.getString("Name"),
                        rs.getString("Address"),
                        rs.getInt("Capacity"),
                        rs.getString("Manager"),
                        rs.getString("Contact")
                });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading branches: " + ex.getMessage());
        }
    }

    // ===== Add Branch =====
    private void addBranch() {
        String name = txtName.getText().trim();
        String address = txtAddress.getText().trim();
        String capacityStr = txtCapacity.getText().trim();
        String manager = txtManager.getText().trim();
        String contact = txtContact.getText().trim();

        if (name.isEmpty() || address.isEmpty() || capacityStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name, Address, and Capacity are required!");
            return;
        }

        try {
            int capacity = Integer.parseInt(capacityStr);
            String sql = "INSERT INTO Branch (Name, Address, Capacity, Manager, Contact) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, name);
                ps.setString(2, address);
                ps.setInt(3, capacity);
                ps.setString(4, manager);
                ps.setString(5, contact);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Branch added successfully!");
                loadBranches();
                clearFields();
            }

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Capacity must be a number!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding branch: " + ex.getMessage());
        }
    }

    // ===== Update Branch =====
    private void updateBranch() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a branch to update!");
            return;
        }

        String sql = "UPDATE Branch SET Name=?, Address=?, Capacity=?, Manager=?, Contact=? WHERE BranchID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, txtName.getText().trim());
            ps.setString(2, txtAddress.getText().trim());
            ps.setInt(3, Integer.parseInt(txtCapacity.getText().trim()));
            ps.setString(4, txtManager.getText().trim());
            ps.setString(5, txtContact.getText().trim());
            ps.setInt(6, selectedId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Branch updated successfully!");
            loadBranches();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating branch: " + ex.getMessage());
        }
    }

    // ===== Delete Branch =====
    private void deleteBranch() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a branch to delete!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this branch?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM Branch WHERE BranchID=?")) {

            ps.setInt(1, selectedId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Branch deleted!");
            loadBranches();
            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting branch: " + ex.getMessage());
        }
    }

    // ===== Helper =====
    private void clearFields() {
        txtName.setText("");
        txtAddress.setText("");
        txtCapacity.setText("");
        txtManager.setText("");
        txtContact.setText("");
        selectedId = -1;
    }
}
