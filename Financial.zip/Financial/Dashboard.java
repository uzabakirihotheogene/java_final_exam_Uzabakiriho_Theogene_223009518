package fms.dashboard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame implements ActionListener {

    // Navigation buttons
    JButton accountHolderBtn = new JButton("Account Holders");
    JButton accountBtn = new JButton("Accounts");
    JButton transactionBtn = new JButton("Transactions");
    JButton loanBtn = new JButton("Loans");
    JButton branchBtn = new JButton("Branches");
    JButton cardBtn = new JButton("Cards");
    JButton logoutBtn = new JButton("Logout");

    // Main content area
    JPanel contentPanel = new JPanel();

    public Dashboard(String role, int userId) {   
        setTitle("Finance Monitoring System - Dashboard");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ===== Header / Navbar =====
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        navPanel.setBackground(new Color(173, 216, 230));

        JButton[] buttons = {accountHolderBtn, accountBtn, transactionBtn, loanBtn, branchBtn, cardBtn, logoutBtn};
        for (JButton btn : buttons) {
            btn.setPreferredSize(new Dimension(140, 35));
            btn.setBackground(new Color(224, 255, 255));
            btn.setFocusPainted(false);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btn.addActionListener(this);
            navPanel.add(btn);
        }

        // ===== Content Area =====
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);

        // Initial content (welcome message)
        JLabel welcome = new JLabel("Welcome to Finance Monitoring System", SwingConstants.CENTER);
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        contentPanel.add(welcome, BorderLayout.CENTER);

        // ===== Add to Frame =====
        add(navPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == logoutBtn) {
            int confirm = JOptionPane.showConfirmDialog(this, "Logout from system?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
            	dispose();
            	new fms.login.Loginform();
            	}
            return;
        }

        // Clear content panel first
        contentPanel.removeAll();

        if (src == accountHolderBtn) {
            contentPanel.add(new fms.crud.AccountHolderPanel(), BorderLayout.CENTER);
        } else if (src == accountBtn) {
            contentPanel.add(new fms.crud.AccountPanel(), BorderLayout.CENTER);
        } else if (src == transactionBtn) {
            contentPanel.add(new fms.crud.TransactionPanel(), BorderLayout.CENTER);
        } else if (src == loanBtn) {
            contentPanel.add(new fms.crud.LoanPanel(), BorderLayout.CENTER);
        } else if (src == branchBtn) {
            contentPanel.add(new fms.crud.BranchPanel(), BorderLayout.CENTER);
        } else if (src == cardBtn) {
            contentPanel.add(new fms.crud.CardPanel(), BorderLayout.CENTER);
        }

        // Refresh content area
        contentPanel.revalidate();
        contentPanel.repaint();
    }
}
